package com.globalcopypaste.app;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.content.ClipData;
import android.content.ClipboardManager;

public class MainActivity extends Activity {
	
	
	private String copiedText = "";
	private String thixtext = "";
	private String clipdata = "";
	private double dummy = 0;
	private HashMap<String, Object> information = new HashMap<>();
	
	private Button button1;
	private TextView textview1;
	private Button button2;
	
	private RequestNetwork GetCopiedText;
	private RequestNetwork.RequestListener _GetCopiedText_request_listener;
	private RequestNetwork SendCopiedText;
	private RequestNetwork.RequestListener _SendCopiedText_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		button1 = (Button) findViewById(R.id.button1);
		textview1 = (TextView) findViewById(R.id.textview1);
		button2 = (Button) findViewById(R.id.button2);
		GetCopiedText = new RequestNetwork(this);
		SendCopiedText = new RequestNetwork(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				GetCopiedText.startRequestNetwork(RequestNetworkController.GET, "http://192.168.0.104:5000", copiedText, _GetCopiedText_request_listener);
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_gshshshs(textview1);
				SendCopiedText.startRequestNetwork(RequestNetworkController.POST, "https://192.168.0.104:5000", "", _SendCopiedText_request_listener);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_gshshshs(textview1);
				thixtext = textview1.getText().toString();
				SketchwareUtil.showMessage(getApplicationContext(), thixtext);
				information.put("1", thixtext);
				SendCopiedText.setParams(information, RequestNetworkController.REQUEST_BODY);
				SendCopiedText.setHeaders(information);
				SendCopiedText.startRequestNetwork(RequestNetworkController.POST, "http://192.168.0.104:5000/", "", _SendCopiedText_request_listener);
				SketchwareUtil.showMessage(getApplicationContext(), "Done");
			}
		});
		
		_GetCopiedText_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _response);
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _response));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_SendCopiedText_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				_gshshshs(textview1);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _test (final String _DemoVar) {
		ClipboardManager clipboard = ((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE));
	}
	
	
	private void _gshshshs (final TextView _text) {
		// Made by Ilyasse Salama
		android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
		ClipData clipData = clipboard.getPrimaryClip();
		if ((clipData != null)) {
			clipdata = clipData.getItemAt(0).getText().toString();;
			_text.setText(clipdata);
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Clipboard is empty!");
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
